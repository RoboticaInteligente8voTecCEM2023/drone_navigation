#!/usr/bin/env python
import sys
import rospy
import cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

# start video capture with video dev0
video = cv2.VideoCapture(0)
# capture dimensions
video.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
video.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)


# cv bridge
bridge = CvBridge()

# final commands
def endCallback():
	print("Shutting down")
	cv2.destroyAllWindows()

# ROS node initialization and config
rospy.init_node("webcam_publisher")
image_pub = rospy.Publisher("/video_source/raw",Image,queue_size=1)
image_pub_comp = rospy.Publisher("/video_source/raw_comp",Image,queue_size=1)
rospy.on_shutdown(endCallback)
rate = rospy.Rate(10)

def main(args):
    try:
        if not video.isOpened():
            print("Unable to load camera")
            return
        print("Publishing webcam image ...")
        while not rospy.is_shutdown():
            ret, frame = video.read()
            comp_frame = cv2.resize(frame, (75,75))
            image_pub.publish(bridge.cv2_to_imgmsg(frame,"bgr8"))
            image_pub_comp.publish(bridge.cv2_to_imgmsg(comp_frame,"bgr8"))
            rate.sleep()
    except rospy.ROSInterruptException:
        rospy.logerr("ROS Interrupt Exception.")

if __name__ == "__main__":
	if len(sys.argv) == 1:
		main(sys.argv)
	else:
		print("Incorrect Usage")
